<img width="1236" alt="Screenshot 2022-06-23 at 7 44 10 PM" src="https://user-images.githubusercontent.com/90202062/175320797-90ff0347-0436-4c44-913a-f46a241d14ab.png">
https://fareed-ahmad7.github.io/Responsive-Ecommerce-website-/
